-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: utopia
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `flight_status`
--

DROP TABLE IF EXISTS `flight_status`;
/*!50001 DROP VIEW IF EXISTS `flight_status`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `flight_status` AS SELECT 
 1 AS `id`,
 1 AS `route_id`,
 1 AS `airplane_id`,
 1 AS `departure_time`,
 1 AS `reserved_seats`,
 1 AS `seat_price`,
 1 AS `max_capacity`,
 1 AS `passenger_count`,
 1 AS `available_seats`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `guest_booking`
--

DROP TABLE IF EXISTS `guest_booking`;
/*!50001 DROP VIEW IF EXISTS `guest_booking`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `guest_booking` AS SELECT 
 1 AS `id`,
 1 AS `is_active`,
 1 AS `confirmation_code`,
 1 AS `contact_email`,
 1 AS `contact_phone`,
 1 AS `agent_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `user_booking`
--

DROP TABLE IF EXISTS `user_booking`;
/*!50001 DROP VIEW IF EXISTS `user_booking`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user_booking` AS SELECT 
 1 AS `id`,
 1 AS `is_active`,
 1 AS `confirmation_code`,
 1 AS `user_id`,
 1 AS `agent_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `flight_passengers`
--

DROP TABLE IF EXISTS `flight_passengers`;
/*!50001 DROP VIEW IF EXISTS `flight_passengers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `flight_passengers` AS SELECT 
 1 AS `flight_id`,
 1 AS `booking_id`,
 1 AS `passenger_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `flight_status`
--

/*!50001 DROP VIEW IF EXISTS `flight_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ajpongress`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `flight_status` AS select `flight`.`id` AS `id`,`flight`.`route_id` AS `route_id`,`flight`.`airplane_id` AS `airplane_id`,`flight`.`departure_time` AS `departure_time`,`flight`.`reserved_seats` AS `reserved_seats`,`flight`.`seat_price` AS `seat_price`,`airplane_capacity`.`max_capacity` AS `max_capacity`,`flight_passenger_count`.`passenger_count` AS `passenger_count`,((`airplane_capacity`.`max_capacity` - `flight`.`reserved_seats`) - `flight_passenger_count`.`passenger_count`) AS `available_seats` from ((`flight` join (select `airplane`.`id` AS `id`,`airplane_type`.`max_capacity` AS `max_capacity` from (`airplane` join `airplane_type` on((`airplane`.`type_id` = `airplane_type`.`id`)))) `airplane_capacity` on((`flight`.`airplane_id` = `airplane_capacity`.`id`))) join (select `flight_passengers`.`flight_id` AS `flight_id`,count(0) AS `passenger_count` from `flight_passengers` group by `flight_passengers`.`flight_id`) `flight_passenger_count` on((`flight`.`id` = `flight_passenger_count`.`flight_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `guest_booking`
--

/*!50001 DROP VIEW IF EXISTS `guest_booking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ajpongress`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `guest_booking` AS select `booking`.`id` AS `id`,`booking`.`is_active` AS `is_active`,`booking`.`confirmation_code` AS `confirmation_code`,`booking_guest`.`contact_email` AS `contact_email`,`booking_guest`.`contact_phone` AS `contact_phone`,`booking_agent`.`agent_id` AS `agent_id` from ((`booking` join `booking_guest` on((`booking`.`id` = `booking_guest`.`booking_id`))) left join `booking_agent` on((`booking`.`id` = `booking_agent`.`booking_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_booking`
--

/*!50001 DROP VIEW IF EXISTS `user_booking`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ajpongress`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `user_booking` AS select `booking`.`id` AS `id`,`booking`.`is_active` AS `is_active`,`booking`.`confirmation_code` AS `confirmation_code`,`booking_user`.`user_id` AS `user_id`,`booking_agent`.`agent_id` AS `agent_id` from ((`booking` join `booking_user` on((`booking`.`id` = `booking_user`.`booking_id`))) left join `booking_agent` on((`booking`.`id` = `booking_agent`.`booking_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `flight_passengers`
--

/*!50001 DROP VIEW IF EXISTS `flight_passengers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ajpongress`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `flight_passengers` AS select `flight_bookings`.`flight_id` AS `flight_id`,`flight_bookings`.`booking_id` AS `booking_id`,`passenger`.`id` AS `passenger_id` from ((`flight_bookings` join `passenger` on((`flight_bookings`.`booking_id` = `passenger`.`booking_id`))) join `booking` on((`flight_bookings`.`booking_id` = `booking`.`id`))) where (`booking`.`is_active` = true) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-30 20:41:53
